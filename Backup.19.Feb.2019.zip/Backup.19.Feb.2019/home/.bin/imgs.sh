#!/bin/bash


mpv --vo=vdpau --hwdec=vdpau --no-audio --loop-file --geometry=200 ~/Dropbox/Shit/14628815_1801000123518522_3334732567050977280_n.mp4 &

mpv --vo=vdpau --hwdec=vdpau --no-audio --loop-file --geometry=200 ~/Dropbox/Shit/16756430_1414517128579077_3697233527729815552_n.mp4 &

mpv --vo=vdpau --hwdec=vdpau --no-audio --loop-file --geometry=200 ~/Dropbox/Shit/17687293_1940020202897078_313178496849412096_n.mp4 &

mpv --vo=vdpau --hwdec=vdpau --no-audio --loop-file --geometry=200 ~/Dropbox/Shit/17886004_963970170405785_768731156651704320_n.mp4 &

mpv --vo=vdpau --hwdec=vdpau --no-audio --loop-file --geometry=200 ~/Dropbox/Shit/18315532_1470274326348280_1065276950265724928_n.mp4 &

feh -g 200x200 ~/Dropbox/Shit/15538679_154030301747369_6473823790311669760_n.jpg &

feh -g 200x200 ~/Dropbox/Shit/16465514_384154335295091_6802949161428713472_n.jpg &

feh -g 200x200 ~/Dropbox/Shit/17438886_1284071455003492_7454929277180444672_n.jpg &

feh -g 200x200 ~/Dropbox/Shit/18251954_464343683911487_6157737093796724736_n.jpg &

feh -g 200x200 ~/Dropbox/Shit/15048064_1140630636032458_1170942044919562240_n.jpg &

exit 0
